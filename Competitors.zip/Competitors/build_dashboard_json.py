#!/usr/bin/env python3
"""Convert competitor CSVs into combined_dashboard_data.json for the dashboard.

Reads every CSV in the specified directory, computes days_running from dates,
and produces one JSON blob keyed by broker name.

Usage:
    python3 build_dashboard_json.py                    # reads from current dir
    python3 build_dashboard_json.py --dir path/to/csvs  # reads from specified dir
"""

import csv
import json
import os
import sys
from datetime import datetime
from pathlib import Path

def parse_date(s):
    """Parse YYYY-MM-DD date string."""
    try:
        return datetime.strptime(s.strip(), "%Y-%m-%d")
    except (ValueError, AttributeError):
        return None

def compute_days(first, last):
    """Compute days between two date strings."""
    d1 = parse_date(first)
    d2 = parse_date(last)
    if d1 and d2:
        return max((d2 - d1).days, 0)
    return 0

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Build combined_dashboard_data.json from CSVs")
    parser.add_argument("--dir", default=".", help="Directory containing CSV files")
    parser.add_argument("--output", default=None, help="Output JSON file path")
    args = parser.parse_args()

    csv_dir = Path(args.dir)
    output_path = args.output or str(csv_dir / "combined_dashboard_data.json")

    combined = {}
    csv_files = sorted(csv_dir.glob("*.csv"))

    if not csv_files:
        print(f"No CSV files found in {csv_dir}")
        sys.exit(1)

    for csv_path in csv_files:
        broker_name = csv_path.stem
        print(f"  Processing {broker_name}... ", end="")

        rows = []
        with open(csv_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Compute days_running if not present
                if "days_running" not in row or not row.get("days_running"):
                    row["days_running"] = str(compute_days(
                        row.get("first_shown_date", ""),
                        row.get("last_shown_date", "")
                    ))

                # Normalize countries_found_in if not present
                if "countries_found_in" not in row or not row.get("countries_found_in"):
                    row["countries_found_in"] = ""

                # Normalize country_count
                if "country_count" not in row or not row.get("country_count"):
                    row["country_count"] = str(
                        len(row.get("countries_found_in", "").split("|"))
                        if row.get("countries_found_in") else "0"
                    )

                rows.append(row)

        combined[broker_name] = rows
        print(f"{len(rows)} ads")

    # Write JSON
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(combined, f, ensure_ascii=False)

    total_ads = sum(len(v) for v in combined.values())
    print(f"\n✓ Wrote {output_path}")
    print(f"  {len(combined)} brokers, {total_ads:,} total ads")

if __name__ == "__main__":
    main()
