#!/bin/bash
# Push updated competitor ad data to GitHub
# Run this after pull_ads.py completes to update the repo
#
# Usage:
#   cd ~/Downloads/Competitors
#   python3 pull_ads.py          # pull fresh data
#   ./push_to_github.sh          # push to GitHub

set -e

REPO_DIR="$HOME/Downloads/ppc-repo"
SRC_DIR="$HOME/Downloads/Competitors"
DASHBOARD_SRC="$SRC_DIR/dashboard_preview.html"

echo "📦 Updating ppc repo with latest competitor ad data..."

# Check repo exists
if [ ! -d "$REPO_DIR/.git" ]; then
  echo "❌ Repo not found at $REPO_DIR"
  echo "   Clone it first: git clone https://github.com/shivank-vibecode/ppc.git $REPO_DIR"
  exit 1
fi

# Pull latest from remote
cd "$REPO_DIR"
git pull --rebase origin main 2>/dev/null || true

# Create directories
mkdir -p competitor-ads/data

# Copy scripts
cp "$SRC_DIR/pull_ads.py" competitor-ads/
cp "$SRC_DIR/build_dashboard_json.py" competitor-ads/

# Copy data
cp "$SRC_DIR/combined_dashboard_data.json" competitor-ads/
cp "$SRC_DIR/api_usage.json" competitor-ads/ 2>/dev/null || true

# Copy CSVs
for f in "$SRC_DIR"/*.csv; do
  [ -f "$f" ] && cp "$f" competitor-ads/data/
done

# Copy dashboard
if [ -f "$DASHBOARD_SRC" ]; then
  cp "$DASHBOARD_SRC" competitor-ad-intel.html
fi

# Commit and push
git add -A
DATE=$(date +"%Y-%m-%d")
TOTAL=$(python3 -c "import json; d=json.load(open('competitor-ads/combined_dashboard_data.json')); print(sum(len(v) for v in d.values()))" 2>/dev/null || echo "?")
git commit -m "Update competitor ad data — ${DATE} (${TOTAL} ads)" || { echo "No changes to push."; exit 0; }
git push origin main

echo ""
echo "✅ Pushed to https://github.com/shivank-vibecode/ppc"
echo "   ${TOTAL} ads across all brokers"
