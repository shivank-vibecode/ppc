#!/usr/bin/env python3
"""
Pull Google Ads Transparency Center data for forex/trading competitors
filtered to Africa & LATAM markets via SerpAPI.

Optimized for the Developer plan (5,000 searches/month, 1,000/hr):
  - Scans all 86 Africa & LATAM regions by default
  - Auto-allocates remaining budget to detail calls (messaging/CTA data)
  - Tracks monthly usage across runs
  - Resumes from where it left off if interrupted

Usage:
    python3 pull_ads.py                          # Full 86-region scan + auto-details
    python3 pull_ads.py --competitor deriv        # Pull one competitor
    python3 pull_ads.py --listing-only            # Listing only, no detail calls
    python3 pull_ads.py --key-markets-only        # Quick 10-region scan
    python3 pull_ads.py --budget 2000             # Cap this run at 2000 calls
    python3 pull_ads.py --dry-run                 # Estimate API calls without running
    python3 pull_ads.py --no-resume               # Ignore previous progress, start fresh
"""

import argparse
import csv
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: 'requests' library required. Install with: pip3 install requests")
    sys.exit(1)

# ── API Configuration ──────────────────────────────────────────────────────────

API_KEY = "74c12e95d4f0a09e13af6129a09adf38ccda9d23d8272f85c7652174887bd36a"
BASE_URL = "https://serpapi.com/search"
RATE_LIMIT_DELAY = 4  # seconds between API calls (Developer plan: 1000/hr = 1 every 3.6s)
MAX_RETRIES = 5
MONTHLY_BUDGET = 5000  # Developer plan

# ── Key Markets (10 — for quick scans with --key-markets-only) ────────────────

KEY_AFRICA = {
    2566: "Nigeria",
    2710: "South Africa",
    2404: "Kenya",
    2818: "Egypt",
    2288: "Ghana",
}

KEY_LATAM = {
    2076: "Brazil",
    2484: "Mexico",
    2032: "Argentina",
    2170: "Colombia",
    2152: "Chile",
}

KEY_REGIONS = {**KEY_AFRICA, **KEY_LATAM}

# ── Full Africa & LATAM Regions (86 total) ────────────────────────────────────

AFRICA_REGIONS = {
    2012: "Algeria", 2204: "Benin", 2108: "Burundi", 2854: "Burkina Faso",
    2120: "Cameroon", 2140: "Central African Republic", 2148: "Chad",
    2178: "Republic of the Congo", 2180: "DR Congo", 2262: "Djibouti",
    2818: "Egypt", 2226: "Equatorial Guinea", 2232: "Eritrea", 2231: "Ethiopia",
    2266: "Gabon", 2270: "The Gambia", 2288: "Ghana", 2324: "Guinea",
    2624: "Guinea-Bissau", 2384: "Cote d'Ivoire", 2404: "Kenya",
    2426: "Lesotho", 2430: "Liberia", 2434: "Libya", 2454: "Malawi",
    2466: "Mali", 2450: "Madagascar", 2478: "Mauritania", 2480: "Mauritius",
    2504: "Morocco", 2508: "Mozambique", 2516: "Namibia", 2562: "Niger",
    2566: "Nigeria", 2646: "Rwanda", 2686: "Senegal", 2690: "Seychelles",
    2694: "Sierra Leone", 2706: "Somalia", 2710: "South Africa",
    2748: "Eswatini", 2788: "Tunisia", 2800: "Uganda", 2834: "Tanzania",
    2716: "Zimbabwe",
}

LATAM_REGIONS = {
    2032: "Argentina", 2044: "The Bahamas", 2052: "Barbados", 2084: "Belize",
    2068: "Bolivia", 2076: "Brazil", 2152: "Chile", 2170: "Colombia",
    2188: "Costa Rica", 2212: "Dominica", 2214: "Dominican Republic",
    2218: "Ecuador", 2222: "El Salvador", 2332: "Haiti", 2340: "Honduras",
    2388: "Jamaica", 2484: "Mexico", 2558: "Nicaragua", 2591: "Panama",
    2600: "Paraguay", 2604: "Peru", 2630: "Puerto Rico", 2740: "Suriname",
    2858: "Uruguay", 2862: "Venezuela", 2028: "Antigua and Barbuda",
    2136: "Cayman Islands", 2660: "Anguilla", 2659: "Saint Kitts and Nevis",
    2662: "Saint Lucia", 2663: "Saint Martin",
    2666: "Saint Pierre and Miquelon",
    2670: "Saint Vincent and the Grenadines", 2500: "Montserrat",
    2780: "Trinidad and Tobago", 2796: "Turks and Caicos Islands",
    2850: "U.S. Virgin Islands", 2092: "British Virgin Islands",
    2312: "Guadeloupe", 2254: "French Guiana", 2474: "Martinique",
}

ALL_TARGET_REGIONS = {**AFRICA_REGIONS, **LATAM_REGIONS}

# ── Competitors ────────────────────────────────────────────────────────────────

COMPETITORS = {
    "AxiCorp":         "AR06413346871212769281",
    "activtrades":     "AR14659622506881613825",
    "admiral":         "AR15556014754588786689",
    "ava":             "AR06189275472442949633",
    "capital":         "AR04235489609632448513",
    "cfi":             "AR07489910042049642497",
    "deriv":           "AR05315522821986713601",
    "etoro":           "AR04607698364631351297",
    "exinity":         "AR14060666571307614209",
    "exness":          "AR13546720476746743809",
    "forex_com":       "AR01571454179132571649",
    "fortrade":        "AR04670427427141320705",
    "fp_markets":      "AR14010948029889118209",
    "fusion_markets":  "AR00708150642941624321",
    "fxcm":            "AR08630173419041718273",
    "fxpro":           "AR14241081311140773889",
    "hf_market":       "AR17470038274029387777",
    "ninjatrader":     "AR13965672821116895233",
    "oanda":           "AR00949049749346975745",
    "pepperstone":     "AR16999130088236646401",
    "tickmill":        "AR16509662146167046145",
    "tradenation":     "AR04511555908257447937",
    "tradestation":    "AR12841614012135243777",
    "vantage":         "AR04282515739132297217",
    "weltrade":        "AR15863532213959131137",
    "xm":              "AR14800846168354979841",
}

# ── CSV Header ─────────────────────────────────────────────────────────────────

CSV_COLUMNS = [
    "advertiser_id", "creative_id", "format", "format_name",
    "first_shown_date", "last_shown_date", "days_running",
    "advertiser_name", "ad_funded_by",
    "countries_found_in", "country_count",
    "ad_type", "call_to_action", "video_link", "video_duration",
    "image_url", "transparency_url",
    "total_regions_detail", "africa_latam_regions_detail",
]

FORMAT_MAP = {"text": 1, "image": 2, "video": 3}

# ── API call counter ───────────────────────────────────────────────────────────

api_call_count = 0
effective_budget = MONTHLY_BUDGET


# ── Monthly Usage Tracking ────────────────────────────────────────────────────

def get_month_key():
    """Current month as YYYY-MM."""
    return datetime.now().strftime("%Y-%m")


def load_usage(output_dir):
    """Load api_usage.json. Returns this month's data."""
    usage_path = os.path.join(output_dir, "api_usage.json")
    month = get_month_key()
    if os.path.exists(usage_path):
        try:
            with open(usage_path, "r") as f:
                data = json.load(f)
            return data.get(month, {"calls_used": 0, "runs": []})
        except (json.JSONDecodeError, KeyError):
            return {"calls_used": 0, "runs": []}
    return {"calls_used": 0, "runs": []}


def save_usage(output_dir, calls_this_run, run_info=None):
    """Save updated usage to api_usage.json."""
    usage_path = os.path.join(output_dir, "api_usage.json")
    month = get_month_key()

    all_data = {}
    if os.path.exists(usage_path):
        try:
            with open(usage_path, "r") as f:
                all_data = json.load(f)
        except json.JSONDecodeError:
            pass

    if month not in all_data:
        all_data[month] = {"calls_used": 0, "runs": []}

    all_data[month]["calls_used"] += calls_this_run
    if run_info:
        all_data[month]["runs"].append(run_info)

    # Atomic write
    tmp_path = usage_path + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump(all_data, f, indent=2)
    os.replace(tmp_path, usage_path)


def get_remaining_budget(output_dir):
    """Returns how many calls remain this month."""
    usage = load_usage(output_dir)
    return max(0, MONTHLY_BUDGET - usage["calls_used"])


# ── Resume / Progress Tracking ────────────────────────────────────────────────
# Listing data is stored in per-competitor cache files (.listing_cache/{name}.json)
# to keep the main progress file small (< 1KB). The progress file only tracks
# which competitors are done and the API call count.

CACHE_DIR_NAME = ".listing_cache"


def _cache_dir(output_dir):
    d = os.path.join(output_dir, CACHE_DIR_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def _atomic_write(path, data):
    """Write JSON data atomically with flush + fsync."""
    tmp_path = path + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, path)


def save_listing_cache(output_dir, name, creative_map):
    """Save one competitor's listing data to a cache file."""
    path = os.path.join(_cache_dir(output_dir), f"{name}.json")
    serialized = serialize_creative_map(creative_map)
    _atomic_write(path, serialized)


def load_listing_cache(output_dir, name):
    """Load one competitor's listing data from cache. Returns creative_map or None."""
    path = os.path.join(_cache_dir(output_dir), f"{name}.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            serialized = json.load(f)
        return deserialize_creative_map(serialized)
    except (json.JSONDecodeError, KeyError):
        return None


def load_progress(output_dir):
    """Load .run_progress.json if it exists."""
    progress_path = os.path.join(output_dir, ".run_progress.json")
    if os.path.exists(progress_path):
        try:
            with open(progress_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, KeyError):
            return None
    return None


def save_progress(output_dir, progress):
    """Save lightweight progress state atomically (no listing data)."""
    progress_path = os.path.join(output_dir, ".run_progress.json")
    # Only store metadata — listing data lives in per-competitor cache files
    lightweight = {
        "run_id": progress.get("run_id", ""),
        "mode": progress.get("mode", ""),
        "completed_listing": progress.get("completed_listing", []),
        "completed_details": progress.get("completed_details", []),
        "api_calls_this_run": progress.get("api_calls_this_run", 0),
    }
    _atomic_write(progress_path, lightweight)


def clear_progress(output_dir):
    """Remove progress file and listing cache on successful completion."""
    progress_path = os.path.join(output_dir, ".run_progress.json")
    if os.path.exists(progress_path):
        os.remove(progress_path)
    # Clean up listing cache
    cache = _cache_dir(output_dir)
    import shutil
    if os.path.isdir(cache):
        shutil.rmtree(cache)


# ── API Request ───────────────────────────────────────────────────────────────

def api_request(params):
    """Make a SerpAPI request with retry, rate limiting, and budget check."""
    global api_call_count

    if api_call_count >= effective_budget:
        print(f"\n    ⚠️  Budget exhausted ({api_call_count}/{effective_budget} calls used)")
        return None

    for attempt in range(MAX_RETRIES):
        try:
            time.sleep(RATE_LIMIT_DELAY)
            resp = requests.get(BASE_URL, params=params, timeout=30)

            if resp.status_code == 200:
                api_call_count += 1  # Only count successful calls
                return resp.json()
            elif resp.status_code == 429:
                wait = 30 * (attempt + 1)  # 30s, 60s, 90s, 120s, 150s
                print(f"    ⏳ Rate limited, waiting {wait}s... (call #{api_call_count})")
                time.sleep(wait)
                continue
            elif resp.status_code >= 500:
                wait = 2 ** (attempt + 1)
                print(f"    ⚠️  Server error {resp.status_code}, retrying in {wait}s...")
                time.sleep(wait)
                continue
            else:
                print(f"    ❌ API error {resp.status_code}: {resp.text[:200]}")
                return None
        except requests.exceptions.RequestException as e:
            wait = 2 ** (attempt + 1)
            print(f"    ⚠️  Request error: {e}, retrying in {wait}s...")
            time.sleep(wait)

    print("    ❌ Max retries exceeded")
    return None


def timestamp_to_date(ts):
    """Convert a Unix timestamp (seconds or milliseconds) to YYYY-MM-DD."""
    if ts is None:
        return ""
    try:
        ts = int(ts)
        if ts > 1e12:
            ts = ts // 1000
        return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")
    except (ValueError, OSError):
        return ""


# ── Phase 1: List Creatives ──────────────────────────────────────────────────

def fetch_ads_for_region(advertiser_id, region_code):
    """Fetch all ad creatives for an advertiser in a specific region (paginated)."""
    creatives = []
    next_token = None

    while True:
        if api_call_count >= effective_budget:
            break

        params = {
            "engine": "google_ads_transparency_center",
            "advertiser_id": advertiser_id,
            "region": str(region_code),
            "num": 100,
            "api_key": API_KEY,
        }
        if next_token:
            params["next_page_token"] = next_token

        data = api_request(params)
        if not data:
            break

        page_creatives = data.get("ad_creatives", [])
        creatives.extend(page_creatives)

        pagination = data.get("serpapi_pagination", {})
        next_token = pagination.get("next_page_token")
        if not next_token or not page_creatives:
            break

    return creatives


def list_competitor_ads(name, advertiser_id, regions):
    """Phase 1: Scan all target regions, deduplicate creatives. Returns creative_map."""
    creative_map = {}  # creative_id → {data, countries: set()}
    regions_with_ads = []

    print(f"\n  📡 Phase 1: Scanning {len(regions)} regions...")

    for region_code, region_name in regions.items():
        if api_call_count >= effective_budget:
            print(f"\n    ⚠️  Budget hit during listing, stopping scan")
            break

        sys.stdout.write(f"\r    Scanning: {region_name:<30} (call #{api_call_count})")
        sys.stdout.flush()

        creatives = fetch_ads_for_region(advertiser_id, region_code)

        if creatives:
            regions_with_ads.append((region_code, region_name, len(creatives)))

        for c in creatives:
            cid = c.get("ad_creative_id", "")
            if cid not in creative_map:
                creative_map[cid] = {
                    "data": c,
                    "countries": set(),
                }
            creative_map[cid]["countries"].add(region_name)

    print()  # newline after progress
    total_regions = len(regions)
    print(f"    📊 Markets with ads: {len(regions_with_ads)}/{total_regions}")
    for _, rname, count in sorted(regions_with_ads, key=lambda x: x[2], reverse=True)[:15]:
        print(f"       • {rname}: {count} creatives")
    if len(regions_with_ads) > 15:
        print(f"       ... and {len(regions_with_ads) - 15} more regions")
    print(f"    🎨 Unique creatives: {len(creative_map)}")

    return creative_map


# ── Phase 2: Detail Fetching ─────────────────────────────────────────────────

def fetch_ad_details(advertiser_id, creative_id):
    """Fetch detailed info for a single ad creative."""
    params = {
        "engine": "google_ads_transparency_center_ad_details",
        "advertiser_id": advertiser_id,
        "creative_id": creative_id,
        "api_key": API_KEY,
    }
    return api_request(params)


def extract_detail_fields(details_data):
    """Extract messaging + region data from the details response."""
    if not details_data:
        return {}, "", 0, 0

    si = details_data.get("search_information", {})
    ad_funded_by = si.get("ad_funded_by") or ""

    # Regions from search_information
    regions = si.get("regions", [])
    total_regions = len(regions)
    africa_latam_count = sum(
        1 for r in regions if r.get("region") and int(r["region"]) in ALL_TARGET_REGIONS
    )

    # Creative content
    creative_content = {}
    ad_creatives = details_data.get("ad_creatives", [])
    if ad_creatives:
        ad = ad_creatives[0]
        creative_content = {
            "call_to_action": ad.get("call_to_action") or "",
            "video_link": ad.get("video_link") or "",
            "video_duration": ad.get("video_duration") or "",
            "detail_image": ad.get("image") or "",
        }

    return creative_content, ad_funded_by, total_regions, africa_latam_count


def fetch_competitor_details(name, advertiser_id, creative_map, num_details, output_dir):
    """Phase 2: Fetch details for top N ads, then write CSV. Returns rows."""
    # Sort by total_days_shown to find top performers
    sorted_creatives = sorted(
        creative_map.items(),
        key=lambda x: int(x[1]["data"].get("total_days_shown", 0) or 0),
        reverse=True,
    )

    detail_results = {}
    actual_details = min(num_details, len(sorted_creatives))

    if actual_details > 0:
        to_detail = sorted_creatives[:actual_details]
        print(f"\n  🔍 Phase 2: Fetching details for top {actual_details} ads...")

        for i, (cid, info) in enumerate(to_detail, 1):
            if api_call_count >= effective_budget:
                print(f"\n    ⚠️  Budget hit during details at {i}/{actual_details}")
                break

            days = info["data"].get("total_days_shown", "?")
            sys.stdout.write(f"\r    Detail {i}/{actual_details} ({days} days, call #{api_call_count})")
            sys.stdout.flush()

            details = fetch_ad_details(advertiser_id, cid)
            content, funded_by, total_reg, af_lat_count = extract_detail_fields(details)
            detail_results[cid] = {
                **content,
                "ad_funded_by": funded_by,
                "total_regions": total_reg,
                "africa_latam_count": af_lat_count,
            }

        print()  # newline

    # Build rows
    rows = []
    for cid, info in sorted_creatives:
        df = detail_results.get(cid)
        row = build_ad_row(info["data"], info["countries"], df)
        rows.append(row)

    # Write CSV
    csv_path = os.path.join(output_dir, f"{name}.csv")
    write_csv(rows, csv_path)
    print(f"  ✅ Wrote {len(rows)} ads → {csv_path}")
    if detail_results:
        print(f"     ({len(detail_results)} with messaging/CTA data)")

    return rows


# ── Build Row & Write CSV ─────────────────────────────────────────────────────

def build_ad_row(creative_data, countries, detail_fields=None):
    """Build a single CSV row."""
    c = creative_data
    fmt_raw = (c.get("format") or "").lower()
    fmt_num = FORMAT_MAP.get(fmt_raw, 0)
    fmt_name = fmt_raw.capitalize() if fmt_raw else ""

    first_shown = timestamp_to_date(c.get("first_shown"))
    last_shown = timestamp_to_date(c.get("last_shown"))

    # Use total_days_shown from listing (no detail call needed!)
    days_running = c.get("total_days_shown", "")
    if days_running == "" and first_shown and last_shown:
        try:
            d1 = datetime.strptime(first_shown, "%Y-%m-%d")
            d2 = datetime.strptime(last_shown, "%Y-%m-%d")
            days_running = (d2 - d1).days
        except ValueError:
            pass

    # Countries from region scanning
    country_list = sorted(countries) if countries else []

    # Detail fields (only populated for ads that got detail calls)
    df = detail_fields or {}

    row = {
        "advertiser_id": c.get("advertiser_id", ""),
        "creative_id": c.get("ad_creative_id", ""),
        "format": fmt_num,
        "format_name": fmt_name,
        "first_shown_date": first_shown,
        "last_shown_date": last_shown,
        "days_running": days_running,
        "advertiser_name": c.get("advertiser", ""),
        "ad_funded_by": df.get("ad_funded_by", ""),
        "countries_found_in": "|".join(country_list),
        "country_count": len(country_list),
        "ad_type": fmt_name,
        "call_to_action": df.get("call_to_action", ""),
        "video_link": df.get("video_link", ""),
        "video_duration": df.get("video_duration", ""),
        "image_url": c.get("image", "") or df.get("detail_image", ""),
        "transparency_url": c.get("details_link", ""),
        "total_regions_detail": df.get("total_regions", ""),
        "africa_latam_regions_detail": df.get("africa_latam_count", ""),
    }
    return row


def write_csv(rows, filepath):
    """Write rows to CSV, sorted by days_running descending."""
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        sorted_rows = sorted(
            rows,
            key=lambda r: int(r["days_running"]) if str(r["days_running"]).isdigit() else 0,
            reverse=True,
        )
        writer.writerows(sorted_rows)


# ── Estimates ─────────────────────────────────────────────────────────────────

def estimate_calls(targets, top_details, num_regions, listing_only, remaining):
    """Estimate API calls without running."""
    listing_calls = len(targets) * num_regions
    pagination_est = len(targets) * max(2, num_regions // 10)
    listing_total = listing_calls + pagination_est

    if listing_only or top_details is not None:
        detail_calls = 0 if listing_only else len(targets) * (top_details or 0)
    else:
        # Auto-detail: use remaining budget after listing
        detail_budget = remaining - listing_total
        per_competitor = max(0, detail_budget // len(targets)) if detail_budget > 0 else 0
        detail_calls = len(targets) * per_competitor

    total = listing_total + detail_calls

    print(f"\n📊 Estimated API calls:")
    print(f"   Listing: {len(targets)} competitors × {num_regions} regions = {listing_calls}")
    print(f"   Pagination (est.): ~{pagination_est}")
    if listing_only:
        print(f"   Details: SKIPPED (--listing-only)")
    elif top_details is not None:
        print(f"   Details: {len(targets)} × {top_details} = {detail_calls}")
    else:
        per_comp = detail_calls // len(targets) if len(targets) else 0
        print(f"   Details (auto): ~{per_comp} per competitor × {len(targets)} = ~{detail_calls}")
    print(f"   ────────────────────────────")
    print(f"   Total estimate: ~{total} calls")
    print(f"   Monthly budget: {MONTHLY_BUDGET:,}")
    print(f"   Already used:   {MONTHLY_BUDGET - remaining:,}")
    print(f"   Remaining:      {remaining:,}")
    gap = remaining - total
    if gap >= 0:
        print(f"   After this run:  ~{gap:,} calls left")
    else:
        print(f"   ⚠️  Over budget by {-gap:,} calls — use --budget or --listing-only")

    est_hours = (total * RATE_LIMIT_DELAY) / 3600
    print(f"\n   ⏱  Estimated runtime: ~{est_hours:.1f} hours")
    return total


# ── Serialization helpers for progress file ───────────────────────────────────

def serialize_creative_map(creative_map):
    """Convert creative_map to JSON-serializable form (sets → lists)."""
    out = {}
    for cid, info in creative_map.items():
        out[cid] = {
            "data": info["data"],
            "countries": sorted(info["countries"]),
        }
    return out


def deserialize_creative_map(serialized):
    """Restore creative_map from serialized form (lists → sets)."""
    out = {}
    for cid, info in serialized.items():
        out[cid] = {
            "data": info["data"],
            "countries": set(info["countries"]),
        }
    return out


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    global api_call_count, effective_budget

    parser = argparse.ArgumentParser(
        description="Pull Google Ads Transparency Center data — Africa & LATAM (Developer plan)"
    )
    parser.add_argument(
        "--competitor", nargs="+",
        help="Competitor name(s) to pull (default: all 26)",
    )
    parser.add_argument(
        "--output-dir", default="/Users/shivankshankar/Downloads/Competitors",
        help="Output directory for CSVs and JSON",
    )
    parser.add_argument(
        "--top-details", type=int, default=None,
        help="Fetch details for exactly N longest-running ads per competitor (overrides auto-allocation)",
    )
    parser.add_argument(
        "--listing-only", action="store_true",
        help="Skip detail calls entirely (saves budget for a second run)",
    )
    parser.add_argument(
        "--key-markets-only", action="store_true",
        help="Scan only 10 key markets instead of all 86 regions",
    )
    parser.add_argument(
        "--budget", type=int, default=None,
        help="Cap total API calls for this run (default: use remaining monthly budget)",
    )
    parser.add_argument(
        "--no-resume", action="store_true",
        help="Ignore saved progress, start fresh",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Estimate API calls without running",
    )
    args = parser.parse_args()

    # ── Determine targets ──
    if args.competitor:
        targets = {}
        for c in args.competitor:
            if c in COMPETITORS:
                targets[c] = COMPETITORS[c]
            else:
                print(f"❌ Unknown competitor: {c}")
                print(f"   Available: {', '.join(sorted(COMPETITORS.keys()))}")
                sys.exit(1)
    else:
        targets = COMPETITORS

    # ── Choose region set ──
    regions_to_scan = KEY_REGIONS if args.key_markets_only else ALL_TARGET_REGIONS

    # ── Budget calculation ──
    os.makedirs(args.output_dir, exist_ok=True)
    monthly_remaining = get_remaining_budget(args.output_dir)
    usage_this_month = MONTHLY_BUDGET - monthly_remaining

    if args.budget:
        effective_budget = min(args.budget, monthly_remaining)
    else:
        effective_budget = monthly_remaining

    # ── Dry run ──
    if args.dry_run:
        estimate_calls(
            targets, args.top_details, len(regions_to_scan),
            args.listing_only, effective_budget,
        )
        return

    # ── Budget warning ──
    if effective_budget <= 0:
        print(f"⚠️  Monthly budget exhausted ({usage_this_month:,}/{MONTHLY_BUDGET:,} used)")
        print(f"   Budget resets next month. Use --budget N to override (at your risk).")
        sys.exit(1)

    # ── Print run info ──
    mode = "KEY MARKETS (10 regions)" if args.key_markets_only else "FULL (all 86 regions)"
    print(f"\n🌍 Pulling ad data for {len(targets)} competitor(s)")
    print(f"   Mode: {mode}")
    print(f"   Budget: {effective_budget:,} calls this run "
          f"({usage_this_month:,}/{MONTHLY_BUDGET:,} used this month)")
    if args.listing_only:
        print(f"   Details: SKIPPED (--listing-only)")
    elif args.top_details is not None:
        print(f"   Details: top {args.top_details} per competitor")
    else:
        print(f"   Details: auto (uses remaining budget after listing)")
    print(f"   Output: {args.output_dir}")
    est_hours = (effective_budget * RATE_LIMIT_DELAY) / 3600
    print(f"   Max runtime: ~{est_hours:.1f} hours")

    # ── Load resume progress ──
    progress = None
    if not args.no_resume:
        progress = load_progress(args.output_dir)
        if progress:
            completed = progress.get("completed_listing", [])
            skippable = [n for n in completed if n in targets]
            if skippable:
                print(f"\n   ♻️  Resuming: {len(skippable)} competitors already listed")
                print(f"      ({', '.join(skippable[:5])}{'...' if len(skippable) > 5 else ''})")
            else:
                progress = None  # no overlap, start fresh

    if not progress:
        progress = {
            "run_id": datetime.now().isoformat(),
            "mode": mode,
            "completed_listing": [],
            "completed_details": [],
            "api_calls_this_run": 0,
        }

    # ══════════════════════════════════════════════════════════════
    #  PHASE 1: Listing — scan all regions for each competitor
    # ══════════════════════════════════════════════════════════════

    all_creative_maps = {}
    # Restore any previously completed listings from per-competitor cache files
    for name in progress.get("completed_listing", []):
        if name in targets:
            cached = load_listing_cache(args.output_dir, name)
            if cached is not None:
                all_creative_maps[name] = cached

    listing_start_calls = api_call_count

    for name, adv_id in targets.items():
        if name in all_creative_maps:
            continue  # already done (resume)

        if api_call_count >= effective_budget:
            print(f"\n⚠️  Budget exhausted during listing phase at {name}")
            break

        print(f"\n{'='*60}")
        print(f"  🏢 {name} ({adv_id})")
        print(f"{'='*60}")

        creative_map = list_competitor_ads(name, adv_id, regions_to_scan)
        all_creative_maps[name] = creative_map

        # Save listing data to per-competitor cache file (not in progress JSON)
        save_listing_cache(args.output_dir, name, creative_map)

        # Save lightweight progress
        progress["completed_listing"].append(name)
        progress["api_calls_this_run"] = api_call_count
        save_progress(args.output_dir, progress)

    listing_calls_used = api_call_count - listing_start_calls
    print(f"\n{'─'*60}")
    print(f"  Phase 1 complete: {listing_calls_used} API calls")
    print(f"  Listed {len(all_creative_maps)} competitors")

    # ══════════════════════════════════════════════════════════════
    #  PHASE 2: Detail fetching — auto-allocate remaining budget
    # ══════════════════════════════════════════════════════════════

    all_data = {}
    competitors_needing_details = [
        n for n in all_creative_maps
        if n not in progress.get("completed_details", [])
    ]

    if args.listing_only:
        # Write CSVs with listing data only
        print(f"\n  Skipping details (--listing-only)")
        for name, cmap in all_creative_maps.items():
            if name in progress.get("completed_details", []):
                continue
            rows = fetch_competitor_details(
                name, targets.get(name, ""), cmap, 0, args.output_dir
            )
            all_data[name] = rows
    else:
        # Calculate detail allocation
        remaining_for_details = effective_budget - api_call_count
        num_needing = len(competitors_needing_details)

        if args.top_details is not None:
            per_competitor = args.top_details
            print(f"\n  🔍 Phase 2: {per_competitor} detail calls per competitor (manual)")
        elif num_needing > 0 and remaining_for_details > 0:
            per_competitor = remaining_for_details // num_needing
            print(f"\n  🔍 Phase 2: Auto-allocating ~{per_competitor} details per competitor")
            print(f"     ({remaining_for_details:,} calls remaining ÷ {num_needing} competitors)")
        else:
            per_competitor = 0
            if remaining_for_details <= 0:
                print(f"\n  ⚠️  No budget remaining for detail calls")

        for name in list(all_creative_maps.keys()):
            cmap = all_creative_maps[name]
            adv_id = targets.get(name, "")

            if name in progress.get("completed_details", []):
                # Load previously written CSV into all_data
                csv_path = os.path.join(args.output_dir, f"{name}.csv")
                if os.path.exists(csv_path):
                    with open(csv_path, "r") as f:
                        reader = csv.DictReader(f)
                        all_data[name] = list(reader)
                continue

            if api_call_count >= effective_budget and per_competitor > 0:
                print(f"\n  ⚠️  Budget exhausted, writing {name} with listing data only")
                per_competitor = 0

            print(f"\n{'='*60}")
            print(f"  🏢 {name}")
            print(f"{'='*60}")

            rows = fetch_competitor_details(
                name, adv_id, cmap, per_competitor, args.output_dir
            )
            all_data[name] = rows

            # Save progress
            progress["completed_details"].append(name)
            progress["api_calls_this_run"] = api_call_count
            save_progress(args.output_dir, progress)

    # ══════════════════════════════════════════════════════════════
    #  Write combined JSON + summary
    # ══════════════════════════════════════════════════════════════

    json_path = os.path.join(args.output_dir, "combined_dashboard_data.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False)
    print(f"\n📊 Dashboard data: {json_path}")

    # Save monthly usage
    save_usage(args.output_dir, api_call_count, {
        "date": datetime.now().isoformat(),
        "calls": api_call_count,
        "mode": mode,
        "competitors": len(all_data),
    })

    # Clear progress file on success
    clear_progress(args.output_dir)

    # Summary
    final_remaining = monthly_remaining - api_call_count
    print(f"\n{'='*60}")
    print(f"  SUMMARY  (API calls this run: {api_call_count:,})")
    print(f"{'='*60}")
    for name, rows in sorted(all_data.items()):
        if rows:
            longest = max(
                (int(r["days_running"]) for r in rows if str(r["days_running"]).isdigit()),
                default=0,
            )
            countries = set()
            for r in rows:
                cf = r.get("countries_found_in", "")
                countries.update(c for c in cf.split("|") if c)
            with_cta = sum(1 for r in rows if r.get("call_to_action"))
            cta_str = f" | {with_cta} with CTA" if with_cta else ""
            print(f"  {name:<20} {len(rows):>4} ads | longest: {longest:>4}d | {len(countries):>2} countries{cta_str}")
        else:
            print(f"  {name:<20}    0 ads")

    print(f"\n  API calls this run: {api_call_count:,}")
    print(f"  Monthly budget:     {final_remaining:,}/{MONTHLY_BUDGET:,} remaining")
    print(f"  Done ✓")


if __name__ == "__main__":
    main()
